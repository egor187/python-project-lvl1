#!/usr/bin/env python

import brain_games.games.fifth as fifth


def main():
    fifth.progression_game()


if __name__ == '__main__':
    main()
