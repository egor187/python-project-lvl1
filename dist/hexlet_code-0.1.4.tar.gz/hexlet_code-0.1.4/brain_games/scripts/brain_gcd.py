#!/usr/bin/env python

import brain_games.games.fourth as fourth


def main():
    fourth.gcd_game()


if __name__ == '__main__':
    main()
