#!/usr/bin/env python

import brain_games.sec


def main():
    brain_games.sec.even_greet()
    brain_games.sec.even_game()


if __name__ == '__main__':
    main()
