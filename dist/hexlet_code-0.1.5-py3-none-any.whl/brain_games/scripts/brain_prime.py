#!/usr/bin/env python

import brain_games.games.sixth as sixth


def main():
    sixth.prime_game()


if __name__ == '__main__':
    main()
