#!/usr/bin/env python

import brain_games.games.third as third


def main():
    third.calc_game()


if __name__ == "__main__":
    main()
