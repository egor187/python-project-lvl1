#!/usr/bin/env python

#import brain_games.games.cli
import brain_games.common


def main():
    brain_games.common.greet()
    brain_games.common.welcome_user()


if __name__ == '__main__':
    main()
